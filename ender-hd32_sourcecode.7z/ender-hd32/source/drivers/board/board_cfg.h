/*********/
#ifndef _BSP_CFG_H_ 
#define _BSP_CFG_H_ 
#define  __PRINT_TO_TERMINAL  //debug switch
#endif
