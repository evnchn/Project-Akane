
#pragma once



namespace SdFatUtil {
  int FreeRam();
}

using namespace SdFatUtil;  // NOLINT
